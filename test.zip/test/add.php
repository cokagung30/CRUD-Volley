<?php

require_once('connect.php');
$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$nim = $_POST['nim'];

$query = mysqli_query($conn, "INSERT INTO tb_student(`nim`, `name`, `class`) VALUES('$nim', '$nama', '$kelas')");

if ($query == true){
    $kondisi = 'Berhasil';
    echo json_encode(array('kondisi' => $kondisi));
} else{
    $kondisi = 'Gagal';
    echo json_encode(array('kondisi' => $kondisi));
}


?>