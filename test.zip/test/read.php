<?php
    require_once('connect.php');

    $result = mysqli_query($conn, 'select nim, name, class from tb_student');
    $array = array();

    while($row = mysqli_fetch_assoc($result))
    {
        $array[] = $row;
    }
    if (mysqli_num_rows($result) > 0)
    {
        echo json_encode(array("student" => $array));
    } else{
        $kondisi = "Gagal";
        echo json_encode(array("error" => true, "kondisi" => $kondisi));

    }
?>