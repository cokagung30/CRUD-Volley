<?php
require_once('connect.php');

$nama = $_POST['nama'];
$kelas = $_POST['kelas'];
$nim = $_POST['nim'];

$query = mysqli_query($conn, "UPDATE tb_student SET `name` = '$nama', class = '$kelas' WHERE nim = '$nim'");

if ($query == true){
    $kondisi = 'Berhasil';
    echo json_encode(array('kondisi' => $kondisi));
} else{
    $kondisi = 'Gagal';
    echo json_encode(array('kondisi' => $kondisi));
}

?>