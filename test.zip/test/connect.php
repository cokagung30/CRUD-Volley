<?php
    define('server', 'localhost');
    define('user', 'root');
    define('pass', '');
    define('db', 'test');
    
    $conn = mysqli_connect(server, user, pass, db);
    header("Content-Type: application/json");

?>