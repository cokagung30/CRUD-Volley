<?php
require_once('connect.php');

$nim = $_POST['nim'];

$query = mysqli_query($conn, "DELETE FROM tb_student WHERE `nim` = '$nim'");

if ($query == true){
    $kondisi = 'Berhasil';
    echo json_encode(array('kondisi' => $kondisi));
} else{
    $kondisi = 'Gagal';
    echo json_encode(array('kondisi' => $kondisi));
}

?>